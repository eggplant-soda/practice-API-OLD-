namespace BusinessLogic.Tests
{
    public class UnitTest1
    {
        [Fact]
        public async Task CreateAsync_NullUser_ShouldThrowNullArgumentException()
        {
            //var ex = await Assert.ThrowsAnyAsync<ArgumentNullException>(() => service.Create(null));
            //Assert.IsType<ArgumentNullException>(ex);
            //userRepositoryMoq.Verify(x => x.Create(It.)
        }
    }
}